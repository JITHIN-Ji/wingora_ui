import { serve } from "https://deno.land/std@0.192.0/http/server.ts";

// Simple & reliable email regex
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

serve(async (req) => {
  const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "*", // Allow all headers
};

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const { email } = await req.json();

    // ✅ Check empty email
    if (!email) {
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        { status: 400, headers: corsHeaders }
      );
    }

    // ✅ Validate email format
    if (!EMAIL_REGEX.test(email)) {
      return new Response(
        JSON.stringify({ error: "Enter a valid email address" }),
        { status: 400, headers: corsHeaders }
      );
    }

    // ✅ Send email via Resend
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${Deno.env.get("RESEND_API_KEY")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Wingora <onboarding@resend.dev>",
        to: email,
        subject: "Your subscription is successful 🎉",
        html: `
          <h2>Welcome to Wingora 🚀</h2>
          <p>Thank you for subscribing!</p>

          <p>
            <strong>Wingora</strong> delivers
            <br />
            <em>AI-driven business solutions for startups and growing brands.</em>
          </p>

          <p>You’ll receive:</p>
          <ul>
            <li>AI automation insights</li>
            <li>Business growth strategies</li>
            <li>Exclusive updates</li>
          </ul>

          <p>We’re excited to grow with you 💡</p>

          <br />
          <strong>– Team Wingora</strong>
        `,
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      console.error("Resend error:", err);
      throw new Error("Email send failed");
    }

    return new Response(
      JSON.stringify({ success: true, message: "Subscription successful" }),
      { status: 200, headers: corsHeaders }
    );
  } catch (err) {
    console.error("Email error:", err);
    return new Response(
      JSON.stringify({ error: "Failed to send email" }),
      { status: 500, headers: corsHeaders }
    );
  }
});
